package com.hsy.demo.controller;

import com.hsy.demo.util.CASServiceUtil;
import com.hsy.demo.util.XmlUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.net.URLDecoder;
import java.time.Duration;
import java.util.Map;

@RestController
public class IndexController {


    @Autowired
    StringRedisTemplate stringRedisTemplate;

    /**
     * 单点登录服务前缀
     */
    String casPrefix = "http://localhost:8080/cas";

    @GetMapping("/validateLogin")
    public String validateLogin(@RequestParam(name="ticket") String ticket, @RequestParam(name="service") String service) {
        try {
            String validateUrl = casPrefix + "/serviceValidate";
            String res = CASServiceUtil.getSTValidate(validateUrl, ticket, service);//向cas服务请求兑换登录信息，报文示例在下方
            String error = XmlUtils.getTextForElement(res, "authenticationFailure");
            if (StringUtils.isNotEmpty(error)) {
                throw new Exception(error);
            }
            String principal = XmlUtils.getTextForElement(res, "user");//登录用户名
            if (StringUtils.isEmpty(principal)) {
                throw new Exception("无法从单点登录服务中兑换用户");
            }
            Map<String, Object> attributes = XmlUtils.extractCustomAttributes(res);//更多信息
            String token = "";//TODO 生成本系统的登录凭证,之后返回给前端
            long timeout = 30 * 60L;
            stringRedisTemplate.opsForValue().set("ST::" + ticket,token, Duration.ofSeconds(timeout)); // 存储ticket 和 登录凭证之间的关系,之后登出需要用到
            stringRedisTemplate.opsForValue().set("USER_TOKEN::" + token,token, Duration.ofSeconds(timeout));
            return token;
        }catch (Exception e){
            return null;
        }
    }

    /**
     * 提供到cas注册的登出url,负责接收cas 的统一登出请求,达到统一登出全部客户端。
     * 这个地址必须是白名单,由cas服务器调用,非本系统主动调用
     * @param logoutRequest
     * @throws Exception
     */
    @PostMapping(value = "/logout")
    public void logout(@RequestBody String logoutRequest) throws Exception {
        String logoutRequestStr = URLDecoder.decode(logoutRequest, "utf-8");
        String xmlStr = logoutRequestStr.substring(logoutRequestStr.lastIndexOf("LogoutRequest=") + 15);
        String ticketId = XmlUtils.getTextForElement(xmlStr, "SessionIndex");
        String  token = stringRedisTemplate.opsForValue().get("ST::" + ticketId);
        if (token != null) {
            //拿到登录token。注销登出凭证
            stringRedisTemplate.delete("USER_TOKEN::" + token);
            stringRedisTemplate.delete("ST::" + ticketId);
        }
    }

    /**
     * res 报文示例
     */

    /*
            <cas:serviceResponse xmlns:cas='http://www.yale.edu/tp/cas'>
                <cas:authenticationSuccess>
                    <cas:user>devadmin</cas:user>
                    <cas:attributes>
                        <cas:depId>c75952f3fad04a30bfaa7be6a26e33d7</cas:depId>
                        <cas:id>31f6bd865bfc4d71bbea9bfe5837f1fd</cas:id>
                        <cas:realname>开发管理员</cas:realname>
                        <cas:roleId>4091aaa5d15d4dc9b30a2b72a1ba4cba,d44189943ab94b53a476f103e36aac91</cas:roleId>
                        <cas:username>devadmin</cas:username>
                    </cas:attributes>
                </cas:authenticationSuccess>
            </cas:serviceResponse>
     */
}
