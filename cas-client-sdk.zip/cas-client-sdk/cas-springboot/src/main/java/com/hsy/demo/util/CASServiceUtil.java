package com.hsy.demo.util;

import cn.hutool.http.HttpUtil;
import org.apache.commons.lang3.StringUtils;

public class CASServiceUtil {

	public static void main(String[] args) {
		String serviceUrl = "https://cas.8f8.com.cn:8443/cas/p3/serviceValidate";
		String service = "http://localhost:3003/user/login";
		String ticket = "ST-5-1g-9cNES6KXNRwq-GuRET103sm0-DESKTOP-VKLS8B3";
		String res = getSTValidate(serviceUrl,ticket, service);

		System.out.println("---------res-----"+res);
	}


	/**
     * 验证ST
     */
    public static String getSTValidate(String url,String st, String service){
        url = url+"?service="+service+"&ticket="+st;
        String res =  HttpUtil.get(url,5000);
        if(StringUtils.isBlank(res)){
            throw  new RuntimeException("访问单点登录服务失败");
        }
        return res;
	/*	try {
			CloseableHttpClient httpclient = createHttpClientWithNoSsl();
			HttpGet httpget = new HttpGet(url);
			HttpResponse response = httpclient.execute(httpget);
	        String res = readResponse(response);
	        return StringUtils.defaultIfEmpty(res,null);
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
		return "";*/
	}



}
