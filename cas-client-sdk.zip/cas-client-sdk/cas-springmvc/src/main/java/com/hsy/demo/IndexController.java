package com.hsy.demo;


import org.jasig.cas.client.authentication.AttributePrincipal;
import org.jasig.cas.client.validation.Assertion;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
public class IndexController {

    @GetMapping("/")
    public Map test(HttpServletRequest request){
        Assertion assertion = (Assertion) (request.getSession() == null ? request.getAttribute("_const_cas_assertion_") : request.getSession().getAttribute("_const_cas_assertion_"));
        AttributePrincipal principal = assertion.getPrincipal(); //获取登录人信息
        Map<String,Object> attributes = principal.getAttributes(); //获取登陆人附加信息
        //TODO 登录本系统
        return attributes;
    }

}
